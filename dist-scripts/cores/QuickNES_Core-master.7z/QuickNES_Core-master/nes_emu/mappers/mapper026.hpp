#pragma once

// Konami VRC6 mapper

// Nes_Emu 0.7.0. http://www.slack.net/~ant/

#include "Nes_Mapper.h"

typedef Mapper_Vrc6<3> Mapper026;