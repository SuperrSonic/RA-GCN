bool IsItWayland();
