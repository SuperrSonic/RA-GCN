[![Build Status](https://travis-ci.org/libretro/beetle-wswan-libretro.svg?branch=master)](https://travis-ci.org/libretro/beetle-wswan-libretro)
[![Build status](https://ci.appveyor.com/api/projects/status/9xjw8t7gd001d3na/branch/master?svg=true)](https://ci.appveyor.com/project/bparker06/beetle-wswan-libretro/branch/master)

# Beetle Wonderswan