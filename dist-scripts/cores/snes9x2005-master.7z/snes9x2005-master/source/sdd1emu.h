#include "../copyright"

#ifndef SDD1EMU_H
#define SDD1EMU_H

void SDD1_decompress(uint8_t* out, uint8_t* in, int32_t output_length);
#endif
