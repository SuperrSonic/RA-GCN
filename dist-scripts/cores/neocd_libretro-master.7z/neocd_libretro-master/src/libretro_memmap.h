#if !defined(LIBRETRO_MEMMAP_H)
#define LIBRETRO_MEMMAP_H

namespace Libretro
{
    namespace Memmap
    {
        void init();
    } // namespace Memmap
} // namespace Libretro

#endif // LIBRETRO_MEMMAP_H
