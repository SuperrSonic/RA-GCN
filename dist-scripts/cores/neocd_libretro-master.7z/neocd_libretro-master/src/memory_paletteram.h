#ifndef MEMORY_PALETTERAM_H
#define MEMORY_PALETTERAM_H

#include "memory.h"

extern const Memory::Handlers paletteRamHandlers;

#endif // MEMORY_PALETTERAM_H
