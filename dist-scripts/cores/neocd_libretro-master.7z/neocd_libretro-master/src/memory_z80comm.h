#ifndef MEMORY_Z80COMM_H
#define MEMORY_Z80COMM_H

#include "memory.h"

extern const Memory::Handlers z80CommunicationHandlers;

#endif // MEMORY_Z80COMM_H
