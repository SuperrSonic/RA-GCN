#ifndef MEMORY_CDINTF_H
#define MEMORY_CDINTF_H

#include "memory.h"

extern const Memory::Handlers cdInterfaceHandlers;

#endif // MEMORY_CDINTF_H
