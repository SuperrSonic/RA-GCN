#if !defined(LIBRETRO_INPUT_H)
#define LIBRETRO_INPUT_H

namespace Libretro
{
    namespace Input
    {
        void init();

        void update();
    } // namespace Input
} // namespace Libretro

#endif // LIBRETRO_INPUT_H
