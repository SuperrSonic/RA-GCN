#ifndef MEMORY_SWITCHES_H
#define MEMORY_SWITCHES_H

#include "memory.h"

extern const Memory::Handlers switchHandlers;

#endif // MEMORY_SWITCHES_H
