#ifndef MEMORY_VIDEO_H
#define MEMORY_VIDEO_H

#include "memory.h"

extern const Memory::Handlers videoRamHandlers;

#endif // MEMORY_VIDEO_H
