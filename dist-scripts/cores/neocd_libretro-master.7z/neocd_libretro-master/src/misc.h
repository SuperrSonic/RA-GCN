#ifndef MISC_H
#define MISC_H

#ifndef UNUSED_ARG
#define UNUSED_ARG(x) (void)(x)
#endif

#endif // MISC_H
