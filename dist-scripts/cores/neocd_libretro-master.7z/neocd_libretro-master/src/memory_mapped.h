#ifndef MEMORY_MAPPED_H
#define MEMORY_MAPPED_H

#include "memory.h"

extern const Memory::Handlers mappedRamHandlers;

#endif // MEMORY_MAPPED_H
