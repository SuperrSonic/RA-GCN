#ifndef MEMORY_BACKUPRAM_H
#define MEMORY_BACKUPRAM_H

#include "memory.h"

extern const Memory::Handlers backupRamHandlers;

#endif // MEMORY_BACKUPRAM_H
