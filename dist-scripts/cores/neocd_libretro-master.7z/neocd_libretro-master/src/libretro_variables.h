#if !defined(LIBRETRO_VARIABLES_H)
#define LIBRETRO_VARIABLES_H

namespace Libretro
{
    namespace Variables
    {
        void init();

        void update(bool reset);
    } // namespace Variables
} // namespace Libretro

#endif // LIBRETRO_VARIABLES_H
