#ifndef MEMORY_INPUT_H
#define MEMORY_INPUT_H

#include "memory.h"

extern const Memory::Handlers controller1Handlers;
extern const Memory::Handlers controller2Handlers;
extern const Memory::Handlers controller3Handlers;

#endif // MEMORY_INPUT_H
