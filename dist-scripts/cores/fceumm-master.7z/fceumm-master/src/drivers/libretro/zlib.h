#ifndef _ZLIB_STUB_H
#define _ZLIB_STUB_H

#endif
