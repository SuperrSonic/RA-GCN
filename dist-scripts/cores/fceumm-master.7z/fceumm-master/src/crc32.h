#ifndef _FCEU_CRC32_H
#define _FCEU_CRC32_H

uint32 CalcCRC32(uint32 crc, uint8 *buf, uint32 len);

#endif
