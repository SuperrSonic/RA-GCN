libretro-handy
==============
K. Wilkins' Atari Lynx emultor Handy (http://handy.sourceforge.net/) for libretro
