#define CU_MASK  (0)

#define CU_BPP   (2)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo208____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo208__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo208_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo208_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo216____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo216_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo216r___()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216r_f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo216rc__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216rcf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo232____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo232__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo232_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo232_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#undef  CU_MASK

#define CU_MASK  (1)

#define CU_BPP   (2)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo208___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo208__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo208_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo208_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo216___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo216_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo232___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo232__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo232_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo232_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#undef  CU_MASK

#define CU_MASK  (2)

#define CU_BPP   (2)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo208___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo208__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo208_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo208_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo216___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo216_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo216_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static INT32 CtvDo232___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo232__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static INT32 CtvDo232_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static INT32 CtvDo232_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#undef  CU_MASK



// Filler function
static INT32 CtvDo_______() { return 0; }



// Lookup table for 2 bpp
static CtvDoFn CtvDo2[0x20]={
CtvDo208____,CtvDo208__f_,CtvDo208_c__,CtvDo208_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo216____,CtvDo216__f_,CtvDo216_c__,CtvDo216_cf_,
CtvDo216r___,CtvDo216r_f_,CtvDo216rc__,CtvDo216rcf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo232____,CtvDo232__f_,CtvDo232_c__,CtvDo232_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 2 bpp with Sprite Masking
static CtvDoFn CtvDo2m[0x20]={
CtvDo208___m,CtvDo208__fm,CtvDo208_c_m,CtvDo208_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo216___m,CtvDo216__fm,CtvDo216_c_m,CtvDo216_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo232___m,CtvDo232__fm,CtvDo232_c_m,CtvDo232_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 2 bpp with BgHi
static CtvDoFn CtvDo2b[0x20]={
CtvDo208___b,CtvDo208__fb,CtvDo208_c_b,CtvDo208_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo216___b,CtvDo216__fb,CtvDo216_c_b,CtvDo216_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo232___b,CtvDo232__fb,CtvDo232_c_b,CtvDo232_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};

// Current BPP:
CtvDoFn CtvDoX[0x20];
CtvDoFn CtvDoXM[0x20];
CtvDoFn CtvDoXB[0x20];


