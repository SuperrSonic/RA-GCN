#include "cps.h"

INT32 CtvReady(void)
{
  return 0;
}
