extern INT32 EnableHiscores;

void HiscoreInit();
void HiscoreReset();
void HiscoreApply();
void HiscoreExit();
