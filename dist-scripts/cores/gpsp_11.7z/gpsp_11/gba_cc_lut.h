#ifndef __CC_LUT_H__
#define __CC_LUT_H__

#include "common.h"

extern const u16 gba_cc_lut[];

#endif /* __CC_LUT_H__ */
