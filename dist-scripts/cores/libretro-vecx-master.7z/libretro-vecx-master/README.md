vecx
====

Compiling
------------
for libretro build, make sure to set -DCMAKE_BUILD_TYPE=Libretro

Requirements
------------
(for standalone port)
* `libsdl`
* `sdl_gfx`
* `sdl_image`

Authors
-------

* Valavan Manohararajah - original author
* "Demeth" - libretro port
* dave j - OpenGL rendering
* Rupert Carmichael - Audio
