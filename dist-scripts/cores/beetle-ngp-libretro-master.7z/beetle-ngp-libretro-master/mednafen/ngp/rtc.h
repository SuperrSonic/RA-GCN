#ifndef __NGP_RTC_H
#define __NGP_RTC_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint8_t rtc_read8(uint32_t address);

#ifdef __cplusplus
}
#endif

#endif
