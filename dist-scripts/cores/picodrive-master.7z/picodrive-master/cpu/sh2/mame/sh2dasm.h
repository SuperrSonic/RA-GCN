unsigned DasmSH2(char *buffer, unsigned pc, unsigned short opcode);
