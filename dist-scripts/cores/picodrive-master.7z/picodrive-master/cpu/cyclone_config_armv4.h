#define HAVE_ARMv6 0
#include "cyclone_config.h"
