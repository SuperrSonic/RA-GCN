
void vidCpy8to16(void *dest, void *src, short *pal, int lines_and_flags);

