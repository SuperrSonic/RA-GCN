extern unsigned char gfx_buffer[321*240*2*2];

void emu_stateCb(const char *str);

