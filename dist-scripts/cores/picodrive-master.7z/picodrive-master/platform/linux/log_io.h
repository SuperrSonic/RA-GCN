void log_io_clear(void);
void log_io_dump(void);

