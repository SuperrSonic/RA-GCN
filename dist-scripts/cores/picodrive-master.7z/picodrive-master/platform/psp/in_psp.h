
struct in_default_bind;

void in_psp_init(struct in_default_bind *defbinds);
