// pointers must be word aligned, gammaa_val = -4..16, black_lvl = {0,1,2}
void do_pal_convert(unsigned short *dest, unsigned short *src, int gammaa_val, int black_lvl);
