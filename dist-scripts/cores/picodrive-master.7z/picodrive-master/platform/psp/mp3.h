
// additional stuff for PSP mp3 decoder implementation
extern int mp3_last_error;

int  mp3_init(void);
void mp3_deinit(void);
void mp3_reopen_file(void);

