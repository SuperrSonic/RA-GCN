#ifdef __cplusplus
extern "C" {
#endif

extern HWND FrameWnd;
extern RECT FrameRectMy;
extern RECT EmuScreenRect;

#ifdef __cplusplus
}
#endif
