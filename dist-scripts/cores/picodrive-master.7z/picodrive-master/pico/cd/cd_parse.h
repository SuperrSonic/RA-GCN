
cd_data_t *chd_parse(const char *fname);
cd_data_t *cue_parse(const char *fname);
void        cdparse_destroy(cd_data_t *data);

